const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');

const Question = require('./models/Question');

const app = express();
app.use(cors());
app.use(bodyParser.json());

mongoose.connect('mongodb://127.0.0.1:27017/quizDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

console.log("MongoDB Connected");

app.get('/questions', async (req, res) => {
  const questions = await Question.find();
  res.json(questions);
});

app.post('/add', async (req, res) => {
  const newQ = new Question(req.body);
  await newQ.save();
  res.json({ message: 'Question Added' });
});

app.post('/submit', async (req, res) => {
  const { answers } = req.body;
  const questions = await Question.find();

  let score = 0;
  questions.forEach((q, i) => {
    if (q.correctAnswer === answers[i]) {
      score++;
    }
  });

  res.json({ score, total: questions.length });
});

app.listen(5000, () => {
  console.log('Server running on port 5000');
});