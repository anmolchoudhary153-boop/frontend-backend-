let questions = [];
let current = 0;
let answers = [];

fetch('http://localhost:5000/questions')
  .then(res => res.json())
  .then(data => {
    questions = data;
    loadQuestion();
  });

function loadQuestion() {
  document.getElementById('question').innerText = questions[current].question;
  const optionsDiv = document.getElementById('options');
  optionsDiv.innerHTML = '';

  questions[current].options.forEach(opt => {
    const btn = document.createElement('button');
    btn.className = 'option';
    btn.innerText = opt;
    btn.onclick = () => selectAnswer(opt);
    optionsDiv.appendChild(btn);
  });
}

function selectAnswer(answer) {
  answers[current] = answer;
}

function nextQuestion() {
  current++;
  if (current < questions.length) {
    loadQuestion();
  } else {
    submitQuiz();
  }
}

function submitQuiz() {
  fetch('http://localhost:5000/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ answers })
  })
  .then(res => res.json())
  .then(result => {
    document.body.innerHTML = `<h1>Your Score: ${result.score} / ${result.total}</h1>`;
  });
}